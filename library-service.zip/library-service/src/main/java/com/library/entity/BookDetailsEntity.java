package com.library.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="BOOK_DETAILS",schema = "library")
public class BookDetailsEntity {

	@Id
	@Column(name="id",nullable = false)
	private int id;
	
	@Column(name="book_isbn",nullable = false)
	private String isbn;
	
	@Column(name = "book_title")
	private String title;
	
	@Column(name = "book_author")
	private String author;
	
	@Column(name = "book_tags")
	private String tags;
}
