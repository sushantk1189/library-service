package com.library.mapper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Component;

import com.library.api.BookDetails;
import com.library.api.BookDetailsRequest;
import com.library.common.GenericException;
import com.library.entity.BookDetailsEntity;

@Component
public class BookDetailsMapper {

	public List<BookDetails> csvToObjectConverter(InputStream is) throws GenericException {
		try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
				CSVParser csvParser = new CSVParser(fileReader,
						CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {
			List<BookDetails> bookDetails = new ArrayList<>();
			Iterable<CSVRecord> csvRecords = csvParser.getRecords();
			for (CSVRecord csvRecord : csvRecords) {
				BookDetails bookDetail = BookDetails.builder().id(Integer.parseInt(csvRecord.get("id")))
						.title(csvRecord.get("title")).author(csvRecord.get("author")).isbn(csvRecord.get("isbn"))
						.tags(csvRecord.get("tags")).build();
				bookDetails.add(bookDetail);
			}
			return bookDetails;
		} catch (IOException e) {
			throw new GenericException("fail to parse CSV file: " + e.getMessage());
		}
	}
	
	public BookDetailsEntity requestToEntityConveter(BookDetailsRequest bookDetailsRequest) {
		return BookDetailsEntity.builder()
				.id(bookDetailsRequest.getBookDetails().getId())
				.isbn(bookDetailsRequest.getBookDetails().getIsbn())
				.author(bookDetailsRequest.getBookDetails().getAuthor())
				.title(bookDetailsRequest.getBookDetails().getTitle())
				.tags(bookDetailsRequest.getBookDetails().getTags())
				.build();
	}
}
