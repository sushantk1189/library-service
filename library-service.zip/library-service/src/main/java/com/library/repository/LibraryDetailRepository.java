package com.library.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.library.entity.BookDetailsEntity;

@Repository
public interface LibraryDetailRepository extends CrudRepository<BookDetailsEntity,Integer> {
	
	BookDetailsEntity findByIsbn(String isbn);
	
	@Query(value="SELECT p FROM BookDetailsEntity p WHERE CONCAT(p.isbn,p.author,p.title,p.tags) LIKE %?1%")
	public List<BookDetailsEntity> search(String keyword);
}
