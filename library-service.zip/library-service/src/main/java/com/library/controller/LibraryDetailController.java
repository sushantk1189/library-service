package com.library.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.library.api.BookDetailsRequest;
import com.library.common.CommonResponse;
import com.library.common.GenericException;
import com.library.service.LibraryDetailService;

@RestController
@RequestMapping(path = "/api/v1/library")
public class LibraryDetailController {

	@Autowired
	LibraryDetailService service;

	@PostMapping("/save")
	public ResponseEntity<CommonResponse> saveBookDetails(@RequestBody BookDetailsRequest bookDetailsRequest) {
		CommonResponse commonResponse = service.saveBookDetails(bookDetailsRequest);
		return ResponseEntity.ok(commonResponse);
	}

	@GetMapping("/load/{book}")
	public ResponseEntity<CommonResponse> getBookDetails(@PathVariable("book")String book) {
		CommonResponse commonResponse = service.getBooksDetail(book);
		return ResponseEntity.ok(commonResponse);
	}

	@PutMapping("/update")
	public ResponseEntity<CommonResponse> updateBookDetails(@RequestBody BookDetailsRequest bookDetailsRequest) {
		CommonResponse commonResponse = service.updateBooksDetail(bookDetailsRequest);
		return ResponseEntity.ok(commonResponse);
	}
	
	@DeleteMapping("/delete")
	public ResponseEntity<CommonResponse> deleteBookDetails(@RequestBody BookDetailsRequest bookDetailsRequest) {
		CommonResponse commonResponse = service.deleteBooksDetail(bookDetailsRequest);
		return ResponseEntity.ok(commonResponse);
	}

	@PostMapping(value = "/upload", consumes = { "multipart/form-data" })
	public ResponseEntity<CommonResponse> uploadBookDetails(@RequestParam("file") MultipartFile file) throws GenericException {
		CommonResponse commonResponse = service.save(file);
		return ResponseEntity.ok(commonResponse);
	}
}
