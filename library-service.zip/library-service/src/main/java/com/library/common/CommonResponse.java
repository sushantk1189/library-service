package  com.library.common;

import java.util.List;

import com.library.api.BookDetails;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
@Builder
public class CommonResponse {

	private List<BookDetails> bookDetails;
	private String status;
	private String statusCode;
	private String statusDescription;
}
