package com.library.common;

import org.springframework.http.HttpStatus;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class GenericException extends Exception {

	private static final long serialVersionUID = -8720789619363341078L;
	private static final String FAILURE ="FAILED";
	private static final String FAILURE_CODE ="403";
	private static final String FAILURE_DESC = "Error in processing the request";
	private final CommonErrorResponse responseStatus;

	public GenericException() {
		super();
		responseStatus = new CommonErrorResponse(FAILURE, FAILURE_CODE,
				FAILURE_DESC);
	}
	
	public GenericException(Throwable rootCause) {
		super(rootCause);
		log.error("Error in processing {}", rootCause);
		responseStatus = new CommonErrorResponse(FAILURE, FAILURE_CODE,
				FAILURE_DESC);
	}

	public GenericException(String errorDescription) {
		responseStatus = new CommonErrorResponse(FAILURE, HttpStatus.PRECONDITION_FAILED.toString(),
				errorDescription);
	}
	
	public GenericException(String msg, Throwable rootCause) {
		log.error(msg, rootCause);
		responseStatus = new CommonErrorResponse(FAILURE,  HttpStatus.PRECONDITION_FAILED.toString(), msg);
	}
	
	public GenericException(int errorCode, String errorDescription) {
		responseStatus = new CommonErrorResponse(FAILURE, String.valueOf(errorCode), errorDescription);
	}

	public GenericException(int errorCode, String errorStatus, String errorDescription) {
		responseStatus = new CommonErrorResponse(errorStatus, String.valueOf(errorCode), errorDescription);
	}

	public CommonErrorResponse getResponseStatus() {
		return responseStatus;
	}

}
