package com.library.service;

import org.springframework.web.multipart.MultipartFile;

import com.library.api.BookDetailsRequest;
import com.library.common.CommonResponse;
import com.library.common.GenericException;

public interface LibraryDetailService {

	default CommonResponse saveBookDetails(BookDetailsRequest bookDetailsRequest) {
		return CommonResponse.builder().build();
	}

	CommonResponse getBooksDetail(String book);
	
	CommonResponse updateBooksDetail(BookDetailsRequest bookDetailsRequest);
	
	CommonResponse deleteBooksDetail(BookDetailsRequest bookDetailsRequest);
	
	public CommonResponse save(MultipartFile file) throws GenericException;
}
