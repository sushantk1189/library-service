package com.library.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.library.api.BookDetails;
import com.library.api.BookDetailsRequest;
import com.library.common.CommonResponse;
import com.library.common.GenericException;
import com.library.entity.BookDetailsEntity;
import com.library.mapper.BookDetailsMapper;
import com.library.repository.LibraryDetailRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LibraryDetailServiceImpl implements LibraryDetailService {

	@Autowired
	LibraryDetailRepository libraryDetailRepository;

	@Autowired
	BookDetailsMapper bookDetailsMapper;
	
	private static final String SUCCESS_CODE ="200";
	private static final String SUCCESS = "SUCCESS";

	@Override
	public CommonResponse saveBookDetails(BookDetailsRequest bookDetailsRequest) {
		BookDetailsEntity bookDetailsEntity = bookDetailsMapper.requestToEntityConveter(bookDetailsRequest);
		libraryDetailRepository.save(bookDetailsEntity);
		return CommonResponse.builder().status(SUCCESS).statusCode(SUCCESS_CODE)
				.statusDescription("Book Details Submitted SuccessFully!!!").build();
	}

	@Override
	public CommonResponse getBooksDetail(String book) {
		List<BookDetails> bookDetailData = new ArrayList<>();
		List<BookDetailsEntity> bookDetails = libraryDetailRepository.search(
				book);
		bookDetails.stream().forEach(bookInfo -> {
			BookDetails bookDetail = BookDetails.builder().author(bookInfo.getAuthor()).isbn(bookInfo.getIsbn())
					.tags(bookInfo.getTags()).title(bookInfo.getTitle()).build();
			bookDetailData.add(bookDetail);
		});
		log.info("get book details {}", bookDetailData.toString());
		return CommonResponse.builder().status(SUCCESS).statusCode(SUCCESS_CODE)
				.statusDescription("Book Details Retrieved SuccessFully!!!").bookDetails(bookDetailData).build();
	}

	@Override
	public CommonResponse updateBooksDetail(BookDetailsRequest bookDetailsRequest) {
		BookDetailsEntity bookDetails = libraryDetailRepository
				.findByIsbn(bookDetailsRequest.getBookDetails().getIsbn());
		bookDetails.setAuthor(bookDetailsRequest.getBookDetails().getAuthor());
		bookDetails.setIsbn(bookDetailsRequest.getBookDetails().getIsbn());
		bookDetails.setTitle(bookDetailsRequest.getBookDetails().getTitle());
		bookDetails.setTags(bookDetailsRequest.getBookDetails().getTags());

		libraryDetailRepository.save(bookDetails);
		return CommonResponse.builder().status(SUCCESS).statusCode(SUCCESS_CODE)
				.statusDescription("Book Details Updated SuccessFully!!!").build();
	}

	@Override
	public CommonResponse deleteBooksDetail(BookDetailsRequest bookDetailsRequest) {
		BookDetailsEntity bookDetailsEntity = bookDetailsMapper.requestToEntityConveter(bookDetailsRequest);
		libraryDetailRepository.delete(bookDetailsEntity);
		return CommonResponse.builder().status(SUCCESS).statusCode(SUCCESS_CODE)
				.statusDescription("Book Details Deleted successfully!!!").build();
	}

	@Override
	public CommonResponse save(MultipartFile file) throws GenericException {
		try {
			List<BookDetails> bookDetails = bookDetailsMapper.csvToObjectConverter(file.getInputStream());
			bookDetails.stream().forEach(bookInfo -> {
				BookDetailsEntity bookDetailsEntity = BookDetailsEntity.builder().id(bookInfo.getId())
						.author(bookInfo.getAuthor()).title(bookInfo.getTitle()).tags(bookInfo.getTags())
						.isbn(bookInfo.getIsbn()).build();
				libraryDetailRepository.save(bookDetailsEntity);
			});
			return CommonResponse.builder().status(SUCCESS).statusCode(SUCCESS_CODE)
					.statusDescription("Uploaded the file successfully: " + file.getOriginalFilename()).build();
		} catch (IOException e) {
			throw new GenericException("fail to store csv data: " + e.getMessage());
		}
	}
}
