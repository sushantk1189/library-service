package com.library;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockMultipartFile;
import com.library.api.BookDetails;
import com.library.api.BookDetailsRequest;
import com.library.common.GenericException;
import com.library.entity.BookDetailsEntity;
import com.library.mapper.BookDetailsMapper;

@RunWith(MockitoJUnitRunner.class)
public class BookDetailsMapperTest {

	@InjectMocks
	BookDetailsMapper bookDetailsMapper;

	public static final String targetFolder = "C:/Users/SKHANDAG/Documents/admin-service/src/main/resources/";

	String fileName = "C:/Users/SKHANDAG/Documents/admin-service/src/main/resources/bookdetails.csv";
	File file = new File(targetFolder + fileName);

	MockMultipartFile mockMultipartFile = new MockMultipartFile("user-file", fileName, "text/plain",
			"test data".getBytes());

	@Test
	public void testCSVToObjectConverter() throws GenericException, IOException {
		List<BookDetails> bookDetails = bookDetailsMapper.csvToObjectConverter(mockMultipartFile.getInputStream());
		assertEquals(0, bookDetails.size());
	}
	
	@Test
	public void testRequestToEntityConveter() throws GenericException, IOException {
		BookDetails bookdetail = BookDetails.builder().author("John").isbn("1234").title("3 mistake").tags("ancient").id(12).build();
		BookDetailsRequest bookDetailsRequest = BookDetailsRequest.builder().bookDetails(bookdetail).build();
		BookDetailsEntity bookDetails = bookDetailsMapper.requestToEntityConveter(bookDetailsRequest);
		assertEquals("John", bookDetails.getAuthor());
	}

}
