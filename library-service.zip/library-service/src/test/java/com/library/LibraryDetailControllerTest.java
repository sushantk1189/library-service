package com.library;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;

import com.library.api.BookDetailsRequest;
import com.library.common.CommonResponse;
import com.library.common.GenericException;
import com.library.controller.LibraryDetailController;
import com.library.service.LibraryDetailService;

@RunWith(MockitoJUnitRunner.class)
public class LibraryDetailControllerTest {

	
	@InjectMocks
	LibraryDetailController libraryDetailController;

	@Mock
	LibraryDetailService libraryDetailService;

	@Test
	public void testSaveBookDetails() {
		BookDetailsRequest bookDetailsRequest = BookDetailsRequest.builder().build();
		Mockito.when(libraryDetailService.saveBookDetails(bookDetailsRequest)).thenReturn(CommonResponse.builder().build());
		ResponseEntity<CommonResponse> response = libraryDetailController.saveBookDetails(bookDetailsRequest);
		assertEquals(200, response.getStatusCodeValue());
	}

	@Test
	public void testGetBookDetails() {
		Mockito.when(libraryDetailService.getBooksDetail(Mockito.any())).thenReturn(CommonResponse.builder().build());
		ResponseEntity<CommonResponse> response = libraryDetailController.getBookDetails(Mockito.any());
		assertEquals(200, response.getStatusCodeValue());
	}
	
	@Test
	public void testUploadFile() throws GenericException {	
	    MockMultipartFile csvFile = new MockMultipartFile("data", "bookdetail.csv", "text/plain", "csv".getBytes());
		Mockito.when(libraryDetailService.save(csvFile)).thenReturn(CommonResponse.builder().build());
		ResponseEntity<CommonResponse> response = libraryDetailController.uploadBookDetails(csvFile);
		assertEquals(200, response.getStatusCodeValue());
	}
	
	@Test
	public void testUpdateBookDetails() {
		Mockito.when(libraryDetailService.updateBooksDetail(Mockito.any())).thenReturn(CommonResponse.builder().build());
		ResponseEntity<CommonResponse> response = libraryDetailController.updateBookDetails(Mockito.any());
		assertEquals(200, response.getStatusCodeValue());
	}
	
	@Test
	public void testDeleteBookDetails() {
		Mockito.when(libraryDetailService.deleteBooksDetail(Mockito.any())).thenReturn(CommonResponse.builder().build());
		ResponseEntity<CommonResponse> response = libraryDetailController.deleteBookDetails(Mockito.any());
		assertEquals(200, response.getStatusCodeValue());
	}
}
