package com.library;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockMultipartFile;

import com.ford.gcamp.admin.core.exception.GCAMPException;
import com.library.api.BookDetails;
import com.library.api.BookDetailsRequest;
import com.library.common.CommonResponse;
import com.library.common.GenericException;
import com.library.entity.BookDetailsEntity;
import com.library.mapper.BookDetailsMapper;
import com.library.repository.LibraryDetailRepository;
import com.library.service.LibraryDetailServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class LibraryDetailServiceTest {
	
	@InjectMocks
	LibraryDetailServiceImpl libraryDetailService;
	
	@Mock
	LibraryDetailRepository libraryDetailRepository;

	@Mock
	BookDetailsMapper bookDetailsMapper;
	
	
	@Test
	public void testSaveBookDetails() throws GCAMPException {	
		BookDetails bookdetail = BookDetails.builder().author("John").isbn("1234").title("3 mistake").tags("ancient").id(12).build();
		BookDetailsRequest bookDetailsRequest = BookDetailsRequest.builder().bookDetails(bookdetail).build();
		BookDetailsEntity bookDetailsEntity = BookDetailsEntity.builder().build();
		libraryDetailRepository.save(bookDetailsEntity);
		CommonResponse commonResponse = libraryDetailService
				.saveBookDetails(bookDetailsRequest);
		assertEquals("Book Details Submitted SuccessFully!!!", commonResponse.getStatusDescription());
	}
	
	
	@Test
	public void testGetBookDetails() throws GCAMPException {	
		libraryDetailRepository.search(Mockito.anyString());
		CommonResponse commonResponse = libraryDetailService
				.getBooksDetail(Mockito.anyString());
		assertEquals("Book Details Retrieved SuccessFully!!!", commonResponse.getStatusDescription());
	}
	
	@Test
	public void testUpdateBookDetails() throws GCAMPException {	
		BookDetails bookdetail = BookDetails.builder().author("John").isbn("1234").title("3 mistake").tags("ancient").id(12).build();
		BookDetailsRequest bookDetailsRequest = BookDetailsRequest.builder().bookDetails(bookdetail).build();
		BookDetailsEntity bookDetailsEntity = BookDetailsEntity.builder().build();
		Mockito.when(libraryDetailRepository.findByIsbn(bookDetailsRequest.getBookDetails().getIsbn())).thenReturn(bookDetailsEntity);
		libraryDetailRepository.save(bookDetailsEntity);
		CommonResponse commonResponse = libraryDetailService
				.updateBooksDetail(bookDetailsRequest);
		assertEquals("Book Details Updated SuccessFully!!!", commonResponse.getStatusDescription());
	}
	
	@Test
	public void testDeleteBookDetails() throws GCAMPException {	
		BookDetails bookdetail = BookDetails.builder().author("John").isbn("1234").title("3 mistake").tags("ancient").id(12).build();
		BookDetailsRequest bookDetailsRequest = BookDetailsRequest.builder().bookDetails(bookdetail).build();
		BookDetailsEntity bookDetailsEntity = BookDetailsEntity.builder().build();
		libraryDetailRepository.delete(bookDetailsEntity);
		CommonResponse commonResponse = libraryDetailService
				.deleteBooksDetail(bookDetailsRequest);
		assertEquals("Book Details Deleted successfully!!!", commonResponse.getStatusDescription());
	}
	
	@Test
	public void testFileUpload() throws  GenericException, IOException {	
		MockMultipartFile csvFile = new MockMultipartFile("data", "bookdetail.csv", "text/plain", "csv".getBytes());
		BookDetails bookdetail = BookDetails.builder().author("John").isbn("1234").title("3 mistake").tags("ancient").id(12).build();
		List<BookDetails> bookdetaillist = new ArrayList<>();
		bookdetaillist.add(bookdetail);
		bookDetailsMapper.csvToObjectConverter(csvFile.getInputStream());
		BookDetailsEntity bookDetailsEntity = BookDetailsEntity.builder().build();
		libraryDetailRepository.save(bookDetailsEntity);
		CommonResponse commonResponse = libraryDetailService
				.save(csvFile);
		assertEquals("Uploaded the file successfully: bookdetail.csv", commonResponse.getStatusDescription());
	}

}
